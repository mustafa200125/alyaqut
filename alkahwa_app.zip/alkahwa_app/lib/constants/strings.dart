class AppStrings {
  // اسم التطبيق
  static const String appName = 'الكهوة';
  static const String appSlogan = 'العب، راهن، اربح';
  
  // الشاشة الرئيسية
  static const String home = 'الرئيسية';
  static const String games = 'الألعاب';
  static const String wallet = 'المحفظة';
  static const String profile = 'الملف الشخصي';
  static const String leaderboard = 'المتصدرين';
  
  // الألعاب
  static const String ludo = 'لودو';
  static const String jackaroo = 'جاكرو';
  static const String domino = 'دومنو';
  static const String backgammon = 'طاولي';
  
  // غرف اللعب
  static const String freeRooms = 'غرف مجانية';
  static const String paidRooms = 'غرف مدفوعة';
  static const String createRoom = 'إنشاء غرفة';
  static const String joinRoom = 'الانضمام';
  static const String quickPlay = 'لعب سريع';
  
  // المحفظة والعملات
  static const String balance = 'الرصيد';
  static const String coins = 'عملة';
  static const String deposit = 'إيداع';
  static const String withdraw = 'سحب';
  static const String transactions = 'المعاملات';
  static const String iqd = 'دينار عراقي';
  
  // طرق الدفع
  static const String zainCash = 'زين كاش';
  static const String superKey = 'سوبر كي';
  static const String paymentMethod = 'طريقة الدفع';
  
  // المراهنة
  static const String bet = 'رهان';
  static const String betAmount = 'مبلغ الرهان';
  static const String minBet = 'الحد الأدنى';
  static const String maxBet = 'الحد الأقصى';
  static const String totalPot = 'المجموع الكلي';
  static const String winnings = 'الأرباح';
  
  // المستخدم
  static const String login = 'تسجيل الدخول';
  static const String register = 'إنشاء حساب';
  static const String logout = 'تسجيل الخروج';
  static const String username = 'اسم المستخدم';
  static const String phone = 'رقم الهاتف';
  static const String password = 'كلمة المرور';
  static const String confirmPassword = 'تأكيد كلمة المرور';
  
  // الميزات الاجتماعية
  static const String friends = 'الأصدقاء';
  static const String chat = 'الدردشة';
  static const String voiceChat = 'دردشة صوتية';
  static const String sendGift = 'إرسال هدية';
  static const String invite = 'دعوة';
  
  // الإحصائيات
  static const String wins = 'الانتصارات';
  static const String losses = 'الخسائر';
  static const String winRate = 'نسبة الفوز';
  static const String totalGames = 'مجموع الألعاب';
  static const String level = 'المستوى';
  static const String rank = 'الترتيب';
  
  // البطولات
  static const String tournaments = 'البطولات';
  static const String daily = 'يومية';
  static const String weekly = 'أسبوعية';
  static const String prize = 'الجائزة';
  static const String entryFee = 'رسوم الدخول';
  static const String joinTournament = 'الانضمام للبطولة';
  
  // الإعدادات
  static const String settings = 'الإعدادات';
  static const String sound = 'الصوت';
  static const String music = 'الموسيقى';
  static const String notifications = 'الإشعارات';
  static const String language = 'اللغة';
  
  // الرسائل
  static const String welcomeMessage = 'أهلاً بك في الكهوة!';
  static const String loginSuccess = 'تم تسجيل الدخول بنجاح';
  static const String loginError = 'خطأ في تسجيل الدخول';
  static const String insufficientBalance = 'رصيد غير كافٍ';
  static const String transactionSuccess = 'تمت العملية بنجاح';
  static const String transactionError = 'فشلت العملية';
  
  // أزرار
  static const String confirm = 'تأكيد';
  static const String cancel = 'إلغاء';
  static const String save = 'حفظ';
  static const String back = 'رجوع';
  static const String next = 'التالي';
  static const String play = 'العب';
  static const String share = 'مشاركة';
  static const String create = 'إنشاء';
}
