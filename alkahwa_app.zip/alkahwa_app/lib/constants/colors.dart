import 'package:flutter/material.dart';

class AppColors {
  // الألوان الرئيسية - مستوحاة من القهوة العراقية
  static const Color primary = Color(0xFF6B4423); // بني القهوة الداكن
  static const Color primaryLight = Color(0xFF8B5A3C); // بني فاتح
  static const Color secondary = Color(0xFFD4A574); // بيج ذهبي
  static const Color accent = Color(0xFFFFD700); // ذهبي
  
  // ألوان الخلفية
  static const Color background = Color(0xFFF5F5F5);
  static const Color cardBackground = Color(0xFFFFFFFF);
  static const Color darkBackground = Color(0xFF2C1810);
  
  // ألوان النصوص
  static const Color textPrimary = Color(0xFF2C1810);
  static const Color textSecondary = Color(0xFF6B6B6B);
  static const Color textLight = Color(0xFFFFFFFF);
  
  // ألوان الحالة
  static const Color success = Color(0xFF4CAF50);
  static const Color error = Color(0xFFF44336);
  static const Color warning = Color(0xFFFF9800);
  static const Color info = Color(0xFF2196F3);
  
  // ألوان الألعاب
  static const Color ludo = Color(0xFFE91E63);
  static const Color jackaroo = Color(0xFF9C27B0);
  static const Color domino = Color(0xFF3F51B5);
  static const Color backgammon = Color(0xFF00BCD4);
  
  // ألوان العملات والأرباح
  static const Color coin = Color(0xFFFFD700);
  static const Color profit = Color(0xFF4CAF50);
  static const Color loss = Color(0xFFF44336);
  
  // تدرجات
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [Color(0xFF6B4423), Color(0xFF8B5A3C)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient goldGradient = LinearGradient(
    colors: [Color(0xFFFFD700), Color(0xFFFFA000)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
