class UserModel {
  final String id;
  final String username;
  final String phone;
  final String? avatar;
  final int coins;
  final int level;
  final int wins;
  final int losses;
  final int totalGames;
  final DateTime createdAt;
  final DateTime? lastLogin;
  
  UserModel({
    required this.id,
    required this.username,
    required this.phone,
    this.avatar,
    this.coins = 0,
    this.level = 1,
    this.wins = 0,
    this.losses = 0,
    this.totalGames = 0,
    required this.createdAt,
    this.lastLogin,
  });
  
  double get winRate {
    if (totalGames == 0) return 0;
    return (wins / totalGames) * 100;
  }
  
  // تحويل من Map إلى Object
  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      id: map['id'] ?? '',
      username: map['username'] ?? '',
      phone: map['phone'] ?? '',
      avatar: map['avatar'],
      coins: map['coins'] ?? 0,
      level: map['level'] ?? 1,
      wins: map['wins'] ?? 0,
      losses: map['losses'] ?? 0,
      totalGames: map['totalGames'] ?? 0,
      createdAt: DateTime.parse(map['createdAt']),
      lastLogin: map['lastLogin'] != null 
          ? DateTime.parse(map['lastLogin']) 
          : null,
    );
  }
  
  // تحويل من Object إلى Map
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'username': username,
      'phone': phone,
      'avatar': avatar,
      'coins': coins,
      'level': level,
      'wins': wins,
      'losses': losses,
      'totalGames': totalGames,
      'createdAt': createdAt.toIso8601String(),
      'lastLogin': lastLogin?.toIso8601String(),
    };
  }
  
  // نسخة معدلة من الكائن
  UserModel copyWith({
    String? id,
    String? username,
    String? phone,
    String? avatar,
    int? coins,
    int? level,
    int? wins,
    int? losses,
    int? totalGames,
    DateTime? createdAt,
    DateTime? lastLogin,
  }) {
    return UserModel(
      id: id ?? this.id,
      username: username ?? this.username,
      phone: phone ?? this.phone,
      avatar: avatar ?? this.avatar,
      coins: coins ?? this.coins,
      level: level ?? this.level,
      wins: wins ?? this.wins,
      losses: losses ?? this.losses,
      totalGames: totalGames ?? this.totalGames,
      createdAt: createdAt ?? this.createdAt,
      lastLogin: lastLogin ?? this.lastLogin,
    );
  }
}
