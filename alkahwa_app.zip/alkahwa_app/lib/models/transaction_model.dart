enum TransactionType {
  deposit,      // إيداع
  withdraw,     // سحب
  winnings,     // أرباح من لعبة
  loss,         // خسارة في لعبة
  commission,   // عمولة المنصة (25%)
}

enum PaymentMethod {
  zainCash,
  superKey,
}

enum TransactionStatus {
  pending,
  completed,
  failed,
  cancelled,
}

class TransactionModel {
  final String id;
  final String userId;
  final TransactionType type;
  final int amount; // بالعملات
  final int amountIQD; // بالدينار العراقي
  final PaymentMethod? paymentMethod;
  final TransactionStatus status;
  final String? reference; // رقم مرجعي للمعاملة
  final String? gameId; // إذا كانت من لعبة
  final DateTime createdAt;
  final DateTime? completedAt;
  final String? notes;
  
  TransactionModel({
    required this.id,
    required this.userId,
    required this.type,
    required this.amount,
    required this.amountIQD,
    this.paymentMethod,
    this.status = TransactionStatus.pending,
    this.reference,
    this.gameId,
    required this.createdAt,
    this.completedAt,
    this.notes,
  });
  
  String get typeArabic {
    switch (type) {
      case TransactionType.deposit:
        return 'إيداع';
      case TransactionType.withdraw:
        return 'سحب';
      case TransactionType.winnings:
        return 'أرباح';
      case TransactionType.loss:
        return 'خسارة';
      case TransactionType.commission:
        return 'عمولة';
    }
  }
  
  String get statusArabic {
    switch (status) {
      case TransactionStatus.pending:
        return 'قيد المعالجة';
      case TransactionStatus.completed:
        return 'مكتملة';
      case TransactionStatus.failed:
        return 'فاشلة';
      case TransactionStatus.cancelled:
        return 'ملغاة';
    }
  }
  
  String get paymentMethodArabic {
    if (paymentMethod == null) return '-';
    switch (paymentMethod!) {
      case PaymentMethod.zainCash:
        return 'زين كاش';
      case PaymentMethod.superKey:
        return 'سوبر كي';
    }
  }
  
  factory TransactionModel.fromMap(Map<String, dynamic> map) {
    return TransactionModel(
      id: map['id'],
      userId: map['userId'],
      type: TransactionType.values[map['type']],
      amount: map['amount'],
      amountIQD: map['amountIQD'],
      paymentMethod: map['paymentMethod'] != null 
          ? PaymentMethod.values[map['paymentMethod']] 
          : null,
      status: TransactionStatus.values[map['status']],
      reference: map['reference'],
      gameId: map['gameId'],
      createdAt: DateTime.parse(map['createdAt']),
      completedAt: map['completedAt'] != null 
          ? DateTime.parse(map['completedAt']) 
          : null,
      notes: map['notes'],
    );
  }
  
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'userId': userId,
      'type': type.index,
      'amount': amount,
      'amountIQD': amountIQD,
      'paymentMethod': paymentMethod?.index,
      'status': status.index,
      'reference': reference,
      'gameId': gameId,
      'createdAt': createdAt.toIso8601String(),
      'completedAt': completedAt?.toIso8601String(),
      'notes': notes,
    };
  }
}
