enum GameType {
  ludo,
  jackaroo,
  domino,
  backgammon,
}

enum RoomStatus {
  waiting,
  playing,
  finished,
}

class GameRoom {
  final String id;
  final GameType gameType;
  final String hostId;
  final String hostName;
  final int betAmount; // 0 للغرف المجانية
  final int maxPlayers;
  final List<String> playerIds;
  final List<String> playerNames;
  final RoomStatus status;
  final DateTime createdAt;
  final bool isPrivate;
  final String? password;
  
  GameRoom({
    required this.id,
    required this.gameType,
    required this.hostId,
    required this.hostName,
    this.betAmount = 0,
    required this.maxPlayers,
    required this.playerIds,
    required this.playerNames,
    this.status = RoomStatus.waiting,
    required this.createdAt,
    this.isPrivate = false,
    this.password,
  });
  
  bool get isFull => playerIds.length >= maxPlayers;
  bool get isFree => betAmount == 0;
  int get currentPlayers => playerIds.length;
  
  String get gameTypeName {
    switch (gameType) {
      case GameType.ludo:
        return 'لودو';
      case GameType.jackaroo:
        return 'جاكرو';
      case GameType.domino:
        return 'دومنو';
      case GameType.backgammon:
        return 'طاولي';
    }
  }
  
  factory GameRoom.fromMap(Map<String, dynamic> map) {
    return GameRoom(
      id: map['id'],
      gameType: GameType.values[map['gameType']],
      hostId: map['hostId'],
      hostName: map['hostName'],
      betAmount: map['betAmount'] ?? 0,
      maxPlayers: map['maxPlayers'],
      playerIds: List<String>.from(map['playerIds']),
      playerNames: List<String>.from(map['playerNames']),
      status: RoomStatus.values[map['status']],
      createdAt: DateTime.parse(map['createdAt']),
      isPrivate: map['isPrivate'] ?? false,
      password: map['password'],
    );
  }
  
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'gameType': gameType.index,
      'hostId': hostId,
      'hostName': hostName,
      'betAmount': betAmount,
      'maxPlayers': maxPlayers,
      'playerIds': playerIds,
      'playerNames': playerNames,
      'status': status.index,
      'createdAt': createdAt.toIso8601String(),
      'isPrivate': isPrivate,
      'password': password,
    };
  }
}
