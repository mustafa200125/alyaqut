class CurrencyUtils {
  // 10,000 عملة = 1,000 دينار عراقي
  // 1 عملة = 0.1 دينار
  static const int coinsPerIQD = 10;
  
  /// تحويل من العملات إلى الدينار العراقي
  static int coinsToIQD(int coins) {
    return (coins / coinsPerIQD).floor();
  }
  
  /// تحويل من الدينار العراقي إلى العملات
  static int iqdToCoins(int iqd) {
    return iqd * coinsPerIQD;
  }
  
  /// حساب أرباح اللاعب الرابح
  /// اللاعب الرابح يحصل على رهانه + 75% من رهان الخاسر
  static int calculateWinnerPrize(int betAmount) {
    int loserBet = betAmount;
    int winnerShare = (loserBet * 0.75).floor();
    return betAmount + winnerShare; // رهانه + 75% من رهان الخاسر
  }
  
  /// حساب عمولة المنصة (25% من رهان الخاسر)
  static int calculatePlatformCommission(int betAmount) {
    return (betAmount * 0.25).floor();
  }
  
  /// تنسيق العرض للعملات
  static String formatCoins(int coins) {
    if (coins >= 1000000) {
      return '${(coins / 1000000).toStringAsFixed(1)}م'; // مليون
    } else if (coins >= 1000) {
      return '${(coins / 1000).toStringAsFixed(1)}ألف';
    }
    return coins.toString();
  }
  
  /// تنسيق العرض للدينار العراقي
  static String formatIQD(int iqd) {
    if (iqd >= 1000000) {
      return '${(iqd / 1000000).toStringAsFixed(1)}م د.ع'; // مليون دينار
    } else if (iqd >= 1000) {
      return '${(iqd / 1000).toStringAsFixed(1)}ألف د.ع';
    }
    return '$iqd د.ع';
  }
  
  /// مثال على المراهنة
  static Map<String, int> calculateBetExample(int betAmount) {
    int totalPot = betAmount * 2; // رهان اللاعبين
    int winnerPrize = calculateWinnerPrize(betAmount);
    int platformCommission = calculatePlatformCommission(betAmount);
    
    return {
      'betAmount': betAmount,
      'totalPot': totalPot,
      'winnerPrize': winnerPrize,
      'platformCommission': platformCommission,
      'loserLoss': betAmount,
    };
  }
}
