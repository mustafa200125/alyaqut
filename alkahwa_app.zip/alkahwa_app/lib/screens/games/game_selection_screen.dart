import 'package:flutter/material.dart';
import '../../constants/colors.dart';
import '../../constants/strings.dart';
import '../../utils/currency_utils.dart';

class GameSelectionScreen extends StatefulWidget {
  final int gameType; // 0: Ludo, 1: Jackaroo, 2: Domino, 3: Backgammon
  
  const GameSelectionScreen({super.key, required this.gameType});

  @override
  State<GameSelectionScreen> createState() => _GameSelectionScreenState();
}

class _GameSelectionScreenState extends State<GameSelectionScreen> 
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  
  final List<String> gameNames = [
    AppStrings.ludo,
    AppStrings.jackaroo,
    AppStrings.domino,
    AppStrings.backgammon,
  ];
  
  final List<Color> gameColors = [
    AppColors.ludo,
    AppColors.jackaroo,
    AppColors.domino,
    AppColors.backgammon,
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final gameName = gameNames[widget.gameType];
    final gameColor = gameColors[widget.gameType];
    
    return Scaffold(
      appBar: AppBar(
        title: Text(gameName),
        backgroundColor: gameColor,
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          indicatorWeight: 3,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(
              icon: Icon(Icons.sports_esports),
              text: AppStrings.freeRooms,
            ),
            Tab(
              icon: Icon(Icons.monetization_on),
              text: AppStrings.paidRooms,
            ),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _RoomsList(isFree: true, gameColor: gameColor),
          _RoomsList(isFree: false, gameColor: gameColor),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateRoomDialog(context, gameColor),
        backgroundColor: gameColor,
        icon: const Icon(Icons.add),
        label: const Text(AppStrings.createRoom),
      ),
    );
  }

  void _showCreateRoomDialog(BuildContext context, Color gameColor) {
    int betAmount = 0;
    bool isPrivate = false;
    
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text(AppStrings.createRoom),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // نوع الغرفة
                SwitchListTile(
                  title: const Text('غرفة مدفوعة'),
                  value: betAmount > 0,
                  activeColor: gameColor,
                  onChanged: (value) {
                    setState(() {
                      betAmount = value ? 5000 : 0;
                    });
                  },
                ),
                
                if (betAmount > 0) ...[
                  const SizedBox(height: 16),
                  
                  // مبلغ الرهان
                  TextFormField(
                    initialValue: betAmount.toString(),
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: AppStrings.betAmount,
                      suffixText: AppStrings.coins,
                      helperText: '${CurrencyUtils.coinsToIQD(betAmount)} ${AppStrings.iqd}',
                    ),
                    onChanged: (value) {
                      setState(() {
                        betAmount = int.tryParse(value) ?? 0;
                      });
                    },
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // عرض الأرباح المتوقعة
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.success.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.success),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'عند الفوز ستحصل على:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '${CurrencyUtils.formatCoins(CurrencyUtils.calculateWinnerPrize(betAmount))} عملة',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: gameColor,
                          ),
                        ),
                        Text(
                          '(${CurrencyUtils.formatIQD(CurrencyUtils.coinsToIQD(CurrencyUtils.calculateWinnerPrize(betAmount)))})',
                          style: const TextStyle(
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                
                const SizedBox(height: 16),
                
                // غرفة خاصة
                SwitchListTile(
                  title: const Text('غرفة خاصة'),
                  subtitle: const Text('يتطلب كلمة مرور للدخول'),
                  value: isPrivate,
                  activeColor: gameColor,
                  onChanged: (value) {
                    setState(() {
                      isPrivate = value;
                    });
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(AppStrings.cancel),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('تم إنشاء الغرفة بنجاح!'),
                    backgroundColor: AppColors.success,
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: gameColor,
              ),
              child: const Text(AppStrings.create),
            ),
          ],
        ),
      ),
    );
  }
}

class _RoomsList extends StatelessWidget {
  final bool isFree;
  final Color gameColor;

  const _RoomsList({required this.isFree, required this.gameColor});

  @override
  Widget build(BuildContext context) {
    // غرف تجريبية
    final rooms = List.generate(
      10,
      (index) => {
        'host': 'لاعب ${index + 1}',
        'players': '${index % 4 + 1}/4',
        'bet': isFree ? 0 : (index + 1) * 5000,
      },
    );

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            gameColor.withOpacity(0.05),
            Colors.white,
          ],
        ),
      ),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: rooms.length,
        itemBuilder: (context, index) {
          final room = rooms[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: InkWell(
              onTap: () => _showJoinDialog(context, room, gameColor),
              borderRadius: BorderRadius.circular(12),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    // أيقونة المضيف
                    CircleAvatar(
                      radius: 25,
                      backgroundColor: gameColor,
                      child: const Icon(
                        Icons.person,
                        color: Colors.white,
                      ),
                    ),
                    
                    const SizedBox(width: 16),
                    
                    // معلومات الغرفة
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            room['host'] as String,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(
                                Icons.people,
                                size: 16,
                                color: AppColors.textSecondary,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                room['players'] as String,
                                style: const TextStyle(
                                  color: AppColors.textSecondary,
                                ),
                              ),
                              if (!isFree) ...[
                                const SizedBox(width: 16),
                                const Icon(
                                  Icons.monetization_on,
                                  size: 16,
                                  color: AppColors.coin,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  CurrencyUtils.formatCoins(room['bet'] as int),
                                  style: const TextStyle(
                                    color: AppColors.coin,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ],
                      ),
                    ),
                    
                    // زر الانضمام
                    ElevatedButton(
                      onPressed: () => _showJoinDialog(context, room, gameColor),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: gameColor,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 10,
                        ),
                      ),
                      child: const Text(AppStrings.joinRoom),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  void _showJoinDialog(BuildContext context, Map<String, dynamic> room, Color gameColor) {
    final betAmount = room['bet'] as int;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تأكيد الانضمام'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('المضيف: ${room['host']}'),
            Text('اللاعبين: ${room['players']}'),
            if (!isFree) ...[
              const SizedBox(height: 16),
              const Divider(),
              const SizedBox(height: 8),
              Text(
                'مبلغ الرهان: ${CurrencyUtils.formatCoins(betAmount)} عملة',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                '(${CurrencyUtils.formatIQD(CurrencyUtils.coinsToIQD(betAmount))})',
                style: const TextStyle(
                  color: AppColors.textSecondary,
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppColors.success.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'الأرباح المحتملة: ${CurrencyUtils.formatCoins(CurrencyUtils.calculateWinnerPrize(betAmount))} عملة',
                  style: TextStyle(
                    color: gameColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(AppStrings.cancel),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('تم الانضمام للغرفة! جاري بدء اللعبة...'),
                  backgroundColor: AppColors.success,
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: gameColor,
            ),
            child: const Text(AppStrings.confirm),
          ),
        ],
      ),
    );
  }
}
