import 'package:flutter/material.dart';
import '../../constants/colors.dart';
import '../../constants/strings.dart';
import '../../utils/currency_utils.dart';
import '../../models/transaction_model.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  int balance = 50000; // رصيد تجريبي
  
  // معاملات تجريبية
  final List<TransactionModel> transactions = [
    TransactionModel(
      id: '1',
      userId: 'user1',
      type: TransactionType.winnings,
      amount: 17500,
      amountIQD: 1750,
      status: TransactionStatus.completed,
      gameId: 'game1',
      createdAt: DateTime.now().subtract(const Duration(hours: 2)),
      completedAt: DateTime.now().subtract(const Duration(hours: 2)),
    ),
    TransactionModel(
      id: '2',
      userId: 'user1',
      type: TransactionType.loss,
      amount: -10000,
      amountIQD: -1000,
      status: TransactionStatus.completed,
      gameId: 'game2',
      createdAt: DateTime.now().subtract(const Duration(hours: 5)),
      completedAt: DateTime.now().subtract(const Duration(hours: 5)),
    ),
    TransactionModel(
      id: '3',
      userId: 'user1',
      type: TransactionType.deposit,
      amount: 100000,
      amountIQD: 10000,
      paymentMethod: PaymentMethod.zainCash,
      status: TransactionStatus.completed,
      reference: 'ZC123456789',
      createdAt: DateTime.now().subtract(const Duration(days: 1)),
      completedAt: DateTime.now().subtract(const Duration(days: 1)),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            AppColors.primary.withOpacity(0.05),
            Colors.white,
          ],
        ),
      ),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // بطاقة الرصيد
          Card(
            elevation: 8,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: AppColors.primaryGradient,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  const Text(
                    AppStrings.balance,
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white70,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        Icons.monetization_on,
                        color: AppColors.coin,
                        size: 40,
                      ),
                      const SizedBox(width: 12),
                      Text(
                        CurrencyUtils.formatCoins(balance),
                        style: const TextStyle(
                          fontSize: 42,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${CurrencyUtils.formatIQD(CurrencyUtils.coinsToIQD(balance))}',
                    style: const TextStyle(
                      fontSize: 18,
                      color: Colors.white70,
                    ),
                  ),
                  const SizedBox(height: 24),
                  
                  // أزرار الإيداع والسحب
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _showDepositDialog(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: AppColors.primary,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          icon: const Icon(Icons.add_circle),
                          label: const Text(
                            AppStrings.deposit,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _showWithdrawDialog(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: AppColors.primary,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          icon: const Icon(Icons.remove_circle),
                          label: const Text(
                            AppStrings.withdraw,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // عنوان المعاملات
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                AppStrings.transactions,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textPrimary,
                ),
              ),
              TextButton(
                onPressed: () {},
                child: const Text('عرض الكل'),
              ),
            ],
          ),
          
          const SizedBox(height: 8),
          
          // قائمة المعاملات
          ...transactions.map((transaction) => _TransactionCard(
                transaction: transaction,
              )),
        ],
      ),
    );
  }

  void _showDepositDialog(BuildContext context) {
    int amount = 10000;
    PaymentMethod paymentMethod = PaymentMethod.zainCash;
    
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text(AppStrings.deposit),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // اختيار طريقة الدفع
                const Text(
                  AppStrings.paymentMethod,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                
                // زين كاش
                RadioListTile<PaymentMethod>(
                  title: const Text(AppStrings.zainCash),
                  value: PaymentMethod.zainCash,
                  groupValue: paymentMethod,
                  activeColor: AppColors.primary,
                  onChanged: (value) {
                    setState(() {
                      paymentMethod = value!;
                    });
                  },
                ),
                
                // سوبر كي
                RadioListTile<PaymentMethod>(
                  title: const Text(AppStrings.superKey),
                  value: PaymentMethod.superKey,
                  groupValue: paymentMethod,
                  activeColor: AppColors.primary,
                  onChanged: (value) {
                    setState(() {
                      paymentMethod = value!;
                    });
                  },
                ),
                
                const SizedBox(height: 16),
                
                // مبلغ الإيداع
                TextFormField(
                  initialValue: amount.toString(),
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'المبلغ بالدينار العراقي',
                    suffixText: AppStrings.iqd,
                    helperText: '${CurrencyUtils.iqdToCoins(amount)} ${AppStrings.coins}',
                  ),
                  onChanged: (value) {
                    setState(() {
                      amount = int.tryParse(value) ?? 0;
                    });
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(AppStrings.cancel),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                _processDeposit(amount, paymentMethod);
              },
              child: const Text(AppStrings.confirm),
            ),
          ],
        ),
      ),
    );
  }

  void _showWithdrawDialog(BuildContext context) {
    int amount = 10000;
    PaymentMethod paymentMethod = PaymentMethod.zainCash;
    
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text(AppStrings.withdraw),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // رصيدك الحالي
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('رصيدك الحالي:'),
                      Text(
                        '${CurrencyUtils.formatCoins(balance)} عملة',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: AppColors.primary,
                        ),
                      ),
                    ],
                  ),
                ),
                
                const SizedBox(height: 16),
                
                // اختيار طريقة الدفع
                const Text(
                  AppStrings.paymentMethod,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                
                RadioListTile<PaymentMethod>(
                  title: const Text(AppStrings.zainCash),
                  value: PaymentMethod.zainCash,
                  groupValue: paymentMethod,
                  activeColor: AppColors.primary,
                  onChanged: (value) {
                    setState(() {
                      paymentMethod = value!;
                    });
                  },
                ),
                
                RadioListTile<PaymentMethod>(
                  title: const Text(AppStrings.superKey),
                  value: PaymentMethod.superKey,
                  groupValue: paymentMethod,
                  activeColor: AppColors.primary,
                  onChanged: (value) {
                    setState(() {
                      paymentMethod = value!;
                    });
                  },
                ),
                
                const SizedBox(height: 16),
                
                // مبلغ السحب
                TextFormField(
                  initialValue: amount.toString(),
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    labelText: 'المبلغ بالدينار العراقي',
                    suffixText: AppStrings.iqd,
                    helperText: '${CurrencyUtils.iqdToCoins(amount)} ${AppStrings.coins}',
                  ),
                  onChanged: (value) {
                    setState(() {
                      amount = int.tryParse(value) ?? 0;
                    });
                  },
                ),
                
                const SizedBox(height: 12),
                
                // تحذير
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.warning.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppColors.warning),
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.info, color: AppColors.warning),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'سيتم التحويل لنفس الحساب',
                          style: TextStyle(fontSize: 12),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text(AppStrings.cancel),
            ),
            ElevatedButton(
              onPressed: () {
                final coinsToWithdraw = CurrencyUtils.iqdToCoins(amount);
                if (coinsToWithdraw > balance) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(AppStrings.insufficientBalance),
                      backgroundColor: AppColors.error,
                    ),
                  );
                  return;
                }
                Navigator.pop(context);
                _processWithdraw(amount, paymentMethod);
              },
              child: const Text(AppStrings.confirm),
            ),
          ],
        ),
      ),
    );
  }

  void _processDeposit(int amountIQD, PaymentMethod method) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'جاري معالجة الإيداع عبر ${method == PaymentMethod.zainCash ? AppStrings.zainCash : AppStrings.superKey}',
        ),
        backgroundColor: AppColors.info,
      ),
    );
    
    // محاكاة الإيداع
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() {
          balance += CurrencyUtils.iqdToCoins(amountIQD);
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(AppStrings.transactionSuccess),
            backgroundColor: AppColors.success,
          ),
        );
      }
    });
  }

  void _processWithdraw(int amountIQD, PaymentMethod method) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'جاري معالجة السحب عبر ${method == PaymentMethod.zainCash ? AppStrings.zainCash : AppStrings.superKey}',
        ),
        backgroundColor: AppColors.info,
      ),
    );
    
    // محاكاة السحب
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() {
          balance -= CurrencyUtils.iqdToCoins(amountIQD);
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(AppStrings.transactionSuccess),
            backgroundColor: AppColors.success,
          ),
        );
      }
    });
  }
}

class _TransactionCard extends StatelessWidget {
  final TransactionModel transaction;

  const _TransactionCard({required this.transaction});

  @override
  Widget build(BuildContext context) {
    final isPositive = transaction.amount > 0;
    final color = isPositive ? AppColors.success : AppColors.error;
    IconData icon;
    
    switch (transaction.type) {
      case TransactionType.deposit:
        icon = Icons.add_circle;
        break;
      case TransactionType.withdraw:
        icon = Icons.remove_circle;
        break;
      case TransactionType.winnings:
        icon = Icons.emoji_events;
        break;
      case TransactionType.loss:
        icon = Icons.trending_down;
        break;
      case TransactionType.commission:
        icon = Icons.payments;
        break;
    }
    
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.1),
          child: Icon(icon, color: color),
        ),
        title: Text(
          transaction.typeArabic,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(
          '${transaction.createdAt.day}/${transaction.createdAt.month}/${transaction.createdAt.year}',
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              '${isPositive ? '+' : ''}${CurrencyUtils.formatCoins(transaction.amount)}',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              transaction.statusArabic,
              style: TextStyle(
                fontSize: 12,
                color: transaction.status == TransactionStatus.completed
                    ? AppColors.success
                    : AppColors.warning,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
